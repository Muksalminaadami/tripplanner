<?php $__env->startSection('title', 'Destinasi Wisata - TripPlanner'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .dest-card {
        border-radius: 20px;
        overflow: hidden;
        background: #fff;
        border: 1px solid var(--card-border);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .dest-card:hover {
        transform: translateY(-10px);
        box-shadow: var(--shadow-hover);
        border-color: rgba(79,70,229,0.15);
    }
    .dest-card .img-wrap { overflow: hidden; flex-shrink: 0; }
    .dest-card img {
        height: 210px;
        width: 100%;
        object-fit: cover;
        transition: transform 0.7s cubic-bezier(0.25, 0.8, 0.25, 1);
    }
    .dest-card:hover img { transform: scale(1.1); }
    .dest-card .card-body { padding: 18px; flex: 1; }
    .dest-card .card-footer { background: #fff; padding: 0 18px 18px; border: none; }
    .badge-kat {
        background: var(--primary-light);
        color: var(--primary);
        border-radius: 8px;
        font-size: 0.72rem;
        font-weight: 700;
        padding: 4px 10px;
        display: inline-block;
        margin-bottom: 8px;
    }
    .search-box {
        background: #fff;
        border-radius: 20px;
        padding: 24px 28px;
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--card-border);
        margin-bottom: 32px;
    }
    .hero-dest {
        background: linear-gradient(135deg, #1E293B 0%, #334155 100%);
        padding: 48px 0 40px;
        margin-bottom: 0;
    }
    .empty-state {
        text-align: center;
        padding: 60px 20px;
    }
    .empty-state .empty-icon { font-size: 4rem; margin-bottom: 16px; display: block; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="hero-dest">
    <div class="container">
        <div class="anim-fade-up">
            <p class="text-uppercase fw-bold mb-2" style="color:rgba(255,255,255,0.6);font-size:0.78rem;letter-spacing:1px;">Wisata Indonesia</p>
            <h1 class="fw-800 text-white mb-1" style="font-size:2rem;font-weight:800;letter-spacing:-0.5px;">Jelajahi Destinasi Wisata</h1>
            <p style="color:rgba(255,255,255,0.7);font-size:0.9rem;"><?php echo e($destinasi->total()); ?> destinasi tersedia untuk ditemukan</p>
        </div>
    </div>
</div>

<div class="container py-4">
    
    <div class="search-box anim-fade-up" style="animation-delay:0.1s;">
        <form action="<?php echo e(route('destinasi.index')); ?>" method="GET">
            <div class="row g-3 align-items-end">
                <div class="col-12 col-md-5">
                    <label class="form-label">Cari Destinasi</label>
                    <div class="input-group">
                        <span class="input-group-text" style="border-radius:12px 0 0 12px;border:1.5px solid #E2E8F0;border-right:none;background:#F8FAFC;">
                            <i class="bi bi-search" style="color:var(--text-secondary);"></i>
                        </span>
                        <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control"
                               placeholder="Nama destinasi..." style="border-radius:0 12px 12px 0;border-left:none;">
                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label">Kategori</label>
                    <select name="kategori" class="form-select">
                        <option value="">Semua Kategori</option>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id_kategori); ?>" <?php echo e(request('kategori') == $k->id_kategori ? 'selected' : ''); ?>>
                            <?php echo e($k->nama_kategori); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-12 col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary flex-fill">
                        <i class="bi bi-search me-1"></i>Cari
                    </button>
                    <?php if(request('q') || request('kategori')): ?>
                    <a href="<?php echo e(route('destinasi.index')); ?>" class="btn btn-outline-primary">
                        <i class="bi bi-x-lg"></i>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>

    
    <?php if(request('q') || request('kategori')): ?>
    <div class="mb-3 anim-fade">
        <small class="text-secondary">
            Menampilkan <?php echo e($destinasi->total()); ?> hasil
            <?php if(request('q')): ?> untuk "<strong><?php echo e(request('q')); ?></strong>"<?php endif; ?>
            <?php if(request('kategori')): ?>
                <?php $kat = $kategori->firstWhere('id_kategori', request('kategori')); ?>
                <?php if($kat): ?> di kategori <strong><?php echo e($kat->nama_kategori); ?></strong><?php endif; ?>
            <?php endif; ?>
        </small>
    </div>
    <?php endif; ?>

    <div class="row g-4">
        <?php $__empty_1 = true; $__currentLoopData = $destinasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-12 col-sm-6 col-lg-4 anim-fade-up" style="animation-delay:<?php echo e(($loop->index % 9) * 0.07); ?>s;">
            <div class="dest-card card-hover">
                <div class="img-wrap">
                    <img src="<?php echo e($d->foto_url); ?>" alt="<?php echo e($d->nama_destinasi); ?>" loading="lazy" onerror="this.onerror=null;this.src='<?php echo e($d->svg_fallback); ?>'">
                </div>
                <div class="card-body">
                    <span class="badge-kat"><?php echo e($d->kategori->nama_kategori); ?></span>
                    <h5 class="mb-2" style="font-size:1rem;font-weight:700;letter-spacing:-0.3px;"><?php echo e($d->nama_destinasi); ?></h5>
                    <p class="mb-2" style="font-size:0.82rem;color:var(--text-secondary);line-height:1.5;">
                        <i class="bi bi-geo-alt me-1" style="color:var(--primary);"></i><?php echo e($d->lokasi); ?>

                    </p>
                    <div style="font-size:0.82rem;font-weight:600;color:var(--secondary);">
                        <?php echo e($d->harga_tiket > 0 ? 'Rp ' . number_format($d->harga_tiket, 0, ',', '.') : 'Gratis'); ?>

                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('destinasi.show', $d->id_destinasi)); ?>" class="btn btn-primary btn-sm w-100">
                        <i class="bi bi-arrow-right-circle me-1"></i>Lihat Detail
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="empty-state anim-scale">
                <span class="empty-icon">🔍</span>
                <h4 class="fw-700" style="font-weight:700;">Destinasi Tidak Ditemukan</h4>
                <p class="text-secondary mb-4">Coba ubah kata kunci atau pilih kategori yang berbeda.</p>
                <a href="<?php echo e(route('destinasi.index')); ?>" class="btn btn-outline-primary">Reset Pencarian</a>
            </div>
        </div>
        <?php endif; ?>
    </div>

    
    <?php if($destinasi->hasPages()): ?>
    <div class="d-flex justify-content-center mt-5 anim-fade-up">
        <?php echo e($destinasi->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kuliah\RPL\tripplanner-app\resources\views/destinasi/index.blade.php ENDPATH**/ ?>